﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WCFServiceLibrary
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
    public class Service1 : IService1
    {
        public string Login(string username, string password)
        {
            Korisnik k = new Korisnik();
            Korisnik k1 = new Korisnik();
            k.Username = "pera";
            k.Password = "pera12";
            k1.Username = "mika";
            k1.Password = "mika1";
            if (k.Username == username && k.Password == password)
            {
                k.Ime = "Pera";
                k.Prezime = "Peric";
                k.Starost = 25;
                return "Ime: " + k.Ime + "\nPrezime: " + k.Prezime + "\nGodine: " + k.Starost;
            }
            else if (k1.Username == username && k1.Password == password)
            {
                k1.Ime = "Mika";
                k1.Prezime = "Mikic";
                k1.Starost = 22;
                return "Ime: " + k1.Ime + "\nPrezime: " + k1.Prezime + "\nGodine: " + k1.Starost;
            }
            else
            {
                return "Pogresan username ili password";
            }
        }



    }
}
